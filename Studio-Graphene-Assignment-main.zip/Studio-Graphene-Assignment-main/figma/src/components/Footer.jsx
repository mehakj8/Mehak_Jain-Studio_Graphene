import React from "react";
import "../Styles/footer.css";

function Footer() {
  return (
    <div className="footer">
      <div className="foot">
        <p className="copy">Copyright 2022 All Right Reserved By SG</p>
      </div>
    </div>
  );
}

export default Footer;
